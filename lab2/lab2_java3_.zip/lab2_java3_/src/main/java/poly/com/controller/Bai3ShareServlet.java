package poly.com.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet này xử lý 3 URL:
 * 1. /bai3FormServlet (để tải form lần đầu)
 * 2. /form/create (để xử lý nút Create)
 * 3. /form/ud (để xử lý nút UPDATE)
 */
@WebServlet({"/bai3FormServlet", "/form/ud", "/form/create"})
public class Bai3ShareServlet extends HttpServlet {
    
    /**
     * Phương thức doGet:
     * Được gọi khi bạn truy cập trang lần đầu.
     * Tải dữ liệu mặc định lên form.
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        
        // 1. Tạo một Map để lưu thông tin user
        Map<String, Object> map = new HashMap<>();
        
        // 2. Đặt dữ liệu mặc định
        map.put("fullname", "Lê Anh Tú");
        map.put("gender", true); // true cho "Male"
        map.put("country", "VN"); // "VN" cho "Việt Nam"
        
        // 3. Đặt Map vào request scope với tên "user"
        req.setAttribute("user", map);
        
        // 4. Chuyển tiếp đến trang form.jsp
        //    (ĐÃ SỬA ĐƯỜNG DẪN)
        req.getRequestDispatcher("/form/form.jsp").forward(req, resp);
    }
    
    /**
     * Phương thức doPost:
     * Được gọi khi bạn nhấn nút "Create" hoặc "UPDATE" (vì method="post").
     * Xử lý dữ liệu gửi lên.
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        
        }
    }