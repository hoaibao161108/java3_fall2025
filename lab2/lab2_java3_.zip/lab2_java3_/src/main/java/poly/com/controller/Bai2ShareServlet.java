package poly.com.controller;

import java.io.IOException;

// 1. BỔ SUNG CÁC IMPORT CÒN THIẾU
import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/bai2UserServlet")
public class Bai2ShareServlet extends HttpServlet { // 2. THÊM DẤU {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException { // 3. SỬA LẠI DÒNG NÀY CHO ĐÚNG
        
        // TODO Auto-generated method stub
        req.setAttribute("message", "welcome to fpt poly");
        Map<String, Object> map = new HashMap<>();
        map.put("fullname", "Doan Chi Dat");
        map.put("gender", "male");
        map.put("country", "viet nam");
        req.setAttribute("user", map);
        req.getRequestDispatcher("page.jsp").forward(req, resp);
        
    } // 4. THÊM DẤU } ĐỂ ĐÓNG DOGET

} // 5. THÊM DẤU } ĐỂ ĐÓNG CLASS