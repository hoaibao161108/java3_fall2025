package poly.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.commons.beanutils.BeanUtils;
import poly.dao.DepartmentDAO;
import poly.dao.DepartmentDAOImpl;
import poly.entity.Department;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@WebServlet({
    "/department/index",
    "/department/edit/*",
    "/department/create",
    "/department/update",
    "/department/delete",
    "/department/reset"
})
public class DepartmentServlet extends HttpServlet {
    
    // Hỗ trợ tiếng Việt cho cả chiều đi và chiều về
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        super.service(req, resp);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        processRequest(req, resp);
    }
    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        processRequest(req, resp);
    }
    
    private void processRequest(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            Department form = new Department();
            DepartmentDAO dao = new DepartmentDAOImpl();
            
            // 1. Đổ dữ liệu từ Form vào Bean (nếu có dữ liệu gửi lên)
            if (req.getParameterMap() != null && !req.getParameterMap().isEmpty()) {
                try {
                    BeanUtils.populate(form, req.getParameterMap());
                } catch (IllegalAccessException | InvocationTargetException e) {
                    System.err.println("Lỗi BeanUtils: " + e.getMessage());
                }
            }
            
            String path = req.getServletPath();
            
            // 2. Xử lý logic theo nút bấm
            if (path.contains("edit")) {
                String pathInfo = req.getPathInfo();
                if (pathInfo != null && pathInfo.length() > 1) {
                    String id = pathInfo.substring(1);
                    form = dao.findById(id);
                }
            } 
            else if (path.contains("create")) {
                try {
                    dao.create(form);
                    req.setAttribute("message", "Thêm mới thành công!");
                    form = new Department(); // Reset form sau khi thêm
                } catch (Exception e) {
                    req.setAttribute("error", "Lỗi thêm mới: " + e.getMessage());
                }
            } 
            else if (path.contains("update")) {
                try {
                    dao.update(form);
                    req.setAttribute("message", "Cập nhật thành công!");
                    form = new Department(); // Reset form sau khi sửa
                } catch (Exception e) {
                    req.setAttribute("error", "Lỗi cập nhật: " + e.getMessage());
                }
            } 
            else if (path.contains("delete")) {
                try {
                    dao.deleteById(form.getId());
                    req.setAttribute("message", "Xóa thành công!");
                    form = new Department(); // Reset form sau khi xóa
                } catch (Exception e) {
                    req.setAttribute("error", "Lỗi xóa: " + e.getMessage());
                }
            } 
            else if (path.contains("reset")) {
                form = new Department();
            }

            // 3. Xử lý tìm kiếm & Lấy danh sách hiển thị
            List<Department> list;
            String searchId = req.getParameter("searchId");
            
            if (searchId != null && !searchId.trim().isEmpty()) {
                // Nếu có tìm kiếm
                Department found = dao.findById(searchId.trim());
                if (found != null) {
                    list = Arrays.asList(found);
                    req.setAttribute("message", "Đã tìm thấy phòng ban: " + searchId);
                } else {
                    list = new ArrayList<>(); // List rỗng
                    req.setAttribute("error", "Không tìm thấy phòng ban mã: " + searchId);
                }
            } else {
                // Nếu không tìm kiếm -> Lấy tất cả
                list = dao.findAll();
            }
            
            // 4. Gửi dữ liệu sang JSP
            req.setAttribute("item", form); // Dữ liệu để điền vào các ô input
            req.setAttribute("list", list); // Dữ liệu để vẽ bảng
            
            req.getRequestDispatcher("/views/department/index.jsp").forward(req, resp);
            
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("error", "Lỗi hệ thống: " + e.getMessage());
            req.getRequestDispatcher("/views/department/index.jsp").forward(req, resp);
        }
    }
}