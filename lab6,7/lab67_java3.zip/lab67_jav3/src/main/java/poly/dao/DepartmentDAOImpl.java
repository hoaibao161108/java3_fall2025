package poly.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import poly.entity.Department;
import poly.utils.Jdbc;

public class DepartmentDAOImpl implements DepartmentDAO {
    
    @Override
    public List<Department> findAll() {
        List<Department> list = new ArrayList<>();
        try {
            String sql = "{CALL spSelectAll()}";
            ResultSet rs = Jdbc.executeQueryCallable(sql);
            while (rs.next()) {
                Department d = new Department();
                d.setId(rs.getString("Id"));
                d.setName(rs.getString("Name"));
                d.setDescription(rs.getString("Description"));
                list.add(d);
            }
            rs.getStatement().getConnection().close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    
    @Override
    public Department findById(String id) {
        Department d = null;
        try {
            String sql = "{CALL spSelectById(?)}";
            ResultSet rs = Jdbc.executeQueryCallable(sql, id);
            if (rs.next()) {
                d = new Department();
                d.setId(rs.getString("Id"));
                d.setName(rs.getString("Name"));
                d.setDescription(rs.getString("Description"));
            }
            rs.getStatement().getConnection().close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return d;
    }
    
    @Override
    public void create(Department department) {
        try {
            String sql = "{CALL spInsert(?, ?, ?)}";
            Jdbc.executeUpdateCallable(sql, department.getId(), department.getName(), department.getDescription());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    @Override
    public void update(Department department) {
        try {
            String sql = "{CALL spUpdate(?, ?, ?)}";
            Jdbc.executeUpdateCallable(sql, department.getId(), department.getName(), department.getDescription());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    @Override
    public void deleteById(String id) {
        try {
            String sql = "{CALL spDeleteById(?)}";
            Jdbc.executeUpdateCallable(sql, id);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

