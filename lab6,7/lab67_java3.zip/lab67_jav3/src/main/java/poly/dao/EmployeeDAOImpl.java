package poly.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import poly.entity.Employee;
import poly.utils.Jdbc;

public class EmployeeDAOImpl implements EmployeeDAO {
    
    @Override
    public List<Employee> findAll() {
        List<Employee> list = new ArrayList<>();
        try {
            String sql = "SELECT * FROM Employees";
            ResultSet rs = Jdbc.executeQuery(sql);
            while (rs.next()) {
                Employee e = new Employee();
                e.setId(rs.getString("Id"));
                e.setPassword(rs.getString("Password"));
                e.setFullname(rs.getString("Fullname"));
                e.setPhoto(rs.getString("Photo"));
                e.setGender(rs.getBoolean("Gender"));
                e.setBirthday(rs.getDate("Birthday"));
                e.setSalary(rs.getDouble("Salary"));
                e.setDepartmentId(rs.getString("DepartmentId"));
                list.add(e);
            }
            rs.getStatement().getConnection().close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    
    @Override
    public Employee findById(String id) {
        Employee e = null;
        try {
            String sql = "SELECT * FROM Employees WHERE Id = ?";
            ResultSet rs = Jdbc.executeQuery(sql, id);
            if (rs.next()) {
                e = new Employee();
                e.setId(rs.getString("Id"));
                e.setPassword(rs.getString("Password"));
                e.setFullname(rs.getString("Fullname"));
                e.setPhoto(rs.getString("Photo"));
                e.setGender(rs.getBoolean("Gender"));
                e.setBirthday(rs.getDate("Birthday"));
                e.setSalary(rs.getDouble("Salary"));
                e.setDepartmentId(rs.getString("DepartmentId"));
            }
            rs.getStatement().getConnection().close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return e;
    }
    
    @Override
    public void create(Employee employee) {
        try {
            String sql = "INSERT INTO Employees(Id, Password, Fullname, Photo, Gender, Birthday, Salary, DepartmentId) VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
            Jdbc.executeUpdate(sql, employee.getId(), employee.getPassword(), employee.getFullname(), 
                             employee.getPhoto(), employee.getGender(), employee.getBirthday(), 
                             employee.getSalary(), employee.getDepartmentId());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    @Override
    public void update(Employee employee) {
        try {
            String sql = "UPDATE Employees SET Password=?, Fullname=?, Photo=?, Gender=?, Birthday=?, Salary=?, DepartmentId=? WHERE Id=?";
            Jdbc.executeUpdate(sql, employee.getPassword(), employee.getFullname(), 
                             employee.getPhoto(), employee.getGender(), employee.getBirthday(), 
                             employee.getSalary(), employee.getDepartmentId(), employee.getId());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    @Override
    public void deleteById(String id) {
        try {
            String sql = "DELETE FROM Employees WHERE Id = ?";
            Jdbc.executeUpdate(sql, id);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

