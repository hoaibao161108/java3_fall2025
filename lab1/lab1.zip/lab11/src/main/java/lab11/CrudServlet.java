package lab11; // <-- Sửa lại tên package nếu cần

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CrudServlet
 */
// 1. Ánh xạ Servlet với nhiều URL
@WebServlet(urlPatterns = {
    "/crud/create",
    "/crud/update",
    "/crud/delete",
    "/crud/edit/2024"
})
public class CrudServlet extends HttpServlet {
    
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        
        // Cài đặt kiểu nội dung trả về là HTML và hỗ trợ tiếng Việt
        resp.setContentType("text/html; charset=UTF-8");
        
        PrintWriter out = resp.getWriter();
        
        // 2. Lấy URI (đường dẫn) mà người dùng đã truy cập
        String uri = req.getRequestURI();
        
        out.println("<html><body>");
        
        // 3. Xuất thông báo tương ứng với URI
        if (uri.contains("/crud/create")) {
            out.println("<h1>Bạn đã yêu cầu chức năng: Create (Thêm mới)</h1>");
            
        } else if (uri.contains("/crud/update")) {
            out.println("<h1>Bạn đã yêu cầu chức năng: Update (Cập nhật)</h1>");
            
        } else if (uri.contains("/crud/delete")) {
            out.println("<h1>Bạn đã yêu cầu chức năng: Delete (Xóa)</h1>");
            
        } else if (uri.contains("/crud/edit/2024")) {
            out.println("<h1>Bạn đã yêu cầu chức năng: Edit (Chỉnh sửa) cho năm 2024</h1>");
        }
        
        out.println("</body></html>");
    }
}