package lab11; // <-- Sửa lại tên package nếu cần

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UrlInfoServlet
 */
@WebServlet("/url-info/*") // Dấu /* giúp nhận diện PathInfo
public class UrlInfoServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
	        throws ServletException, IOException {
		
		// Cài đặt kiểu nội dung trả về là HTML và hỗ trợ tiếng Việt
		resp.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = resp.getWriter();
		
		out.println("<html>");
		out.println("<head><title>Bài 3 - Thông Tin URL</title></head>");
		out.println("<body>");
		out.println("<h1>Thông Tin URL</h1>");
		
		// 1. URL
		// (Toàn bộ địa chỉ, bao gồm http://.../...)
		out.println("<p><b>1. URL:</b> " + req.getRequestURL().toString() + "</p>");
		
		// 2. URI
		// (Phần đường dẫn từ sau tên domain, ví dụ: /lab11/url-info/them)
		out.println("<p><b>2. URI:</b> " + req.getRequestURI() + "</p>");
		
		// 3. QueryString
		// (Phần nằm sau dấu ?, ví dụ: ten=bao&tuoi=20)
		out.println("<p><b>3. QueryString:</b> " + req.getQueryString() + "</p>");
		
		// 4. ServletPath
		// (Đường dẫn khớp với @WebServlet, ví dụ: /url-info)
		out.println("<p><b>4. ServletPath:</b> " + req.getServletPath() + "</p>");
		
		// 5. ContextPath
		// (Tên ứng dụng web của bạn, ví dụ: /lab11)
		out.println("<p><b>5. ContextPath:</b> " + req.getContextPath() + "</p>");
		
		// 6. PathInfo
		// (Phần đường dẫn phụ sau ServletPath, ví dụ: /them/duong/dan)
		out.println("<p><b>6. PathInfo:</b> " + req.getPathInfo() + "</p>");
		
		// 7. Method
		// (Phương thức truy cập, ví dụ: GET)
		out.println("<p><b>7. Method:</b> " + req.getMethod() + "</p>");
		
		out.println("</body>");
		out.println("</html>");
	}

}