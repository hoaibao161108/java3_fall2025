package poly.com.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet({"/calculate/add", "/calculate/sub"})
public class CalculateServlet extends HttpServlet {
	@Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        req.setAttribute("message", "Nhập số và chọn phép tính");
        req.getRequestDispatcher("/calculate.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        String a = req.getParameter("a");
        String b = req.getParameter("b");

        String path = req.getServletPath();

        try {
            double numA = Double.parseDouble(a);
            double numB = Double.parseDouble(b);
            double result;

            if(path.endsWith("/add")) {
                result = numA + numB;
                req.setAttribute("message", numA + " + " + numB + " = " + result);
            } else if(path.endsWith("/sub")) {
                result = numA - numB;
                req.setAttribute("message", numA + " - " + numB + " = " + result);
            } else {
                req.setAttribute("message", "Phép tính không hợp lệ");
            }
        } catch(NumberFormatException e) {
            req.setAttribute("message", "Vui lòng nhập đúng số");
        }

        req.getRequestDispatcher("/calculate.jsp").forward(req, resp);
    }
}
