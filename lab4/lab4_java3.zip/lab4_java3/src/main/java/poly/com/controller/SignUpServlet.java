package poly.com.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig; // Thêm cái này để nhận ảnh
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

@MultipartConfig // BẮT BUỘC CÓ dòng này mới upload được file/ảnh
@WebServlet("/signup")
public class SignUpServlet extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.getRequestDispatcher("/signup.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        
        // 1. Cấu hình tiếng Việt
        req.setCharacterEncoding("UTF-8");

        // 2. Nhận dữ liệu từ Form
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String gender   = req.getParameter("gender");
        String country  = req.getParameter("country");
        String note     = req.getParameter("note");
        // Checkbox trả về "true" hoặc null
        boolean married = req.getParameter("married") != null; 
        String[] hobbies = req.getParameterValues("hobby"); // Lưu ý: xem lại bên JSP name là "hobby" hay "hobbies"

        // 3. Xử lý Upload Ảnh
        String photoName = "no-image.png"; // Ảnh mặc định nếu không up
        try {
            Part part = req.getPart("photo"); // "photo" phải trùng name="" bên JSP
            if (part != null && part.getSize() > 0) {
                String filename = Path.of(part.getSubmittedFileName()).getFileName().toString();
                // Tạo thư mục images nếu chưa có
                String realPath = req.getServletContext().getRealPath("/images");
                if (!Files.exists(Paths.get(realPath))) {
                    Files.createDirectories(Paths.get(realPath));
                }
                // Lưu file
                part.write(realPath + "/" + filename);
                photoName = filename;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // 4. Đẩy dữ liệu sang trang kết quả (Thay vì System.out.println)
        req.setAttribute("username", username);
        req.setAttribute("password", password);
        req.setAttribute("gender", gender);
        req.setAttribute("married", married);
        req.setAttribute("country", country);
        req.setAttribute("note", note);
        req.setAttribute("hobbies", hobbies);
        req.setAttribute("photo_name", photoName);

        // 5. Chuyển hướng sang trang hiển thị (result.jsp)
        req.getRequestDispatcher("/result.jsp").forward(req, resp);
    }
}