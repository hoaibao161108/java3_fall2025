package poly.com.filter;

import java.io.IOException;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;

@WebFilter("/*") // Chạy trên mọi request
public class I18nFilter implements Filter {

    @Override
    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain)
            throws IOException, ServletException {
        
        HttpServletRequest httpReq = (HttpServletRequest) req;
        
        // 1. Lấy tham số 'lang' từ trên thanh địa chỉ xuống
        String lang = httpReq.getParameter("lang");
        
        // 2. Nếu người dùng có chọn ngôn ngữ (lang khác null)
        if (lang != null) {
            // Lưu ngôn ngữ đó vào Session để dùng lâu dài
            httpReq.getSession().setAttribute("lang", lang); 
        }
        
        // 3. Cho phép chạy tiếp đến trang đích
        chain.doFilter(req, resp);
    }
}