package poly.com.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;


@WebServlet({ "/home/index", "/home/about", "/home/contact" }) // [cite: 97]
public class HomeServlet extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        
        String uri = req.getRequestURI();
        
        // Kiểm tra đường dẫn để set thuộc tính 'view' tương ứng
        if (uri.contains("index")) {
            req.setAttribute("view", "/views/home/index.jsp"); // [cite: 104]
        } else if (uri.contains("about")) {
            req.setAttribute("view", "/views/home/about.jsp"); // [cite: 105]
        } else if (uri.contains("contact")) {
            req.setAttribute("view", "/views/home/contact.jsp"); // [cite: 106]
        }
        
        // Chuyển hướng về layout chính
        req.getRequestDispatcher("/views/layout.jsp").forward(req, resp); // [cite: 112]
    }
}