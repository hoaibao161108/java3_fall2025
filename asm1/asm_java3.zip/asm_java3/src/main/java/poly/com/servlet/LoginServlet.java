package poly.com.servlet;

import java.io.IOException;

// Import thư viện Jakarta (Chuẩn cho Tomcat 10/11)
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import poly.com.dao.UserDAO;
import poly.com.entity.User;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    private UserDAO dao = new UserDAO();

    // --- 1. Xử lý khi chạy trực tiếp URL hoặc chuyển trang ---
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Chuyển hướng về file JSP giao diện đăng nhập
        // Đường dẫn này tính từ thư mục gốc 'webapp'
        req.getRequestDispatcher("/views/client/login.jsp").forward(req, resp);
    }

    // --- 2. Xử lý khi bấm nút ĐĂNG NHẬP trên Form ---
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        
        // Xử lý tiếng Việt cho dữ liệu đầu vào/đầu ra
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");

        // Lấy thông tin từ form login.jsp
        String id = req.getParameter("id");
        String password = req.getParameter("password");

        // Gọi DAO kiểm tra đăng nhập
        // Hàm này phải khớp tên với bên UserDAO (login hoặc checkLogin)
        User user = dao.login(id, password); 

        // --- TRƯỜNG HỢP ĐĂNG NHẬP THẤT BẠI ---
        if (user == null) {
            req.setAttribute("message", "Sai tài khoản hoặc mật khẩu!");
            // Quay lại trang đăng nhập để hiện lỗi
            req.getRequestDispatcher("/views/client/login.jsp").forward(req, resp);
            return; // Dừng lệnh, không chạy tiếp xuống dưới
        }

        // --- TRƯỜNG HỢP ĐĂNG NHẬP THÀNH CÔNG ---
        HttpSession session = req.getSession();
        session.setAttribute("user", user); // Lưu user vào phiên làm việc

        // Phân quyền dựa trên Role
        // Giả sử: Role = true là Admin, Role = false là Phóng viên/User
        if (Boolean.TRUE.equals(user.getRole())) { 
            // Admin: Chuyển sang Servlet quản lý tin
            resp.sendRedirect("NewsServlet"); 
        } else {
            // Nếu là Phóng viên (Role=0) -> Chuyển vào trang Dashboard của Phóng viên
            // (Hoặc chuyển sang "NewsServlet" nếu bạn muốn load danh sách bài viết luôn)
            resp.sendRedirect("views/reporter/news-manage.jsp");
        }
    }
}