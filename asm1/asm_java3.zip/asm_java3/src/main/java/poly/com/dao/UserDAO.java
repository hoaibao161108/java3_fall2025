package poly.com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import poly.com.entity.User;
import poly.com.util.JdbcHelper;
public class UserDAO {

    public User login(String id, String password) {
    	// Sửa USERS thành users (cho giống hệt trong hình database)
    	String sql = "SELECT * FROM users WHERE id = ? AND password = ?";

        try (Connection con = JdbcHelper.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, id);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                User u = new User();

                u.setId(rs.getString("id"));
                u.setPassword(rs.getString("password"));
                u.setFullname(rs.getString("fullname"));
                u.setBirthday(rs.getDate("birthday"));
                u.setGender(rs.getBoolean("gender"));
             // Sửa 'mobile' thành 'phone'
                u.setMobile(rs.getString("phone"));
                u.setEmail(rs.getString("email"));
                u.setRole(rs.getBoolean("role")); // <-- đúng kiểu Boolean

                return u;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}