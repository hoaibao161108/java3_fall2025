package poly.com.entity; // Nhớ đổi thành poly.com.entity nếu dự án của bạn đang dùng tên đó

public class NewsLetter {
    Integer id;
    String email;
    boolean enabled;

    // Constructor rỗng
    public NewsLetter() {
        // TODO Auto-generated constructor stub
    }

    // Constructor đầy đủ tham số
    public NewsLetter(Integer id, String email, boolean enabled) {
        super();
        this.id = id;
        this.email = email;
        this.enabled = enabled;
    }

    // --- PHẦN GETTER VÀ SETTER (Bổ sung) ---

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
}