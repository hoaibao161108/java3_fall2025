package poly.com.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JdbcHelper {
    // Driver cho SQL Server
    static String driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    
    // 1. ĐÃ SỬA: Tên database thành ABC_News_Poly
    // 2. ĐÃ SỬA: Thêm trustServerCertificate=true để tránh lỗi Driver mới
    static String dburl = "jdbc:sqlserver://localhost:1433;databaseName=News;encrypt=true;trustServerCertificate=true;";
    static String username = "sa";   // Kiểm tra lại user SQL của bạn
    static String password = "1234";  // Kiểm tra lại pass SQL của bạn (thường là 123 hoặc 123456)

    // Khối tĩnh nạp Driver
    static {
        try {
            Class.forName(driver);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("Lỗi nạp Driver SQL Server!", e);
        }
    }

    // Hàm mở kết nối
    public static Connection getConnection() {
        try {
            return DriverManager.getConnection(dburl, username, password);
        } catch (SQLException e) {
            System.out.println("Lỗi kết nối CSDL! Vui lòng kiểm tra user/pass/tên DB.");
            e.printStackTrace();
            return null; 
        }
    }

    // Hàm chuẩn bị câu lệnh (Dùng chung cho cả Query và Update)
    public static PreparedStatement createPreparedStatement(String sql, Object... args) throws SQLException {
        Connection conn = getConnection();
        if (conn == null) return null; // Tránh lỗi NullPointer nếu kết nối thất bại
        
        PreparedStatement pstmt = null;
        if (sql.trim().startsWith("{")) {
            pstmt = conn.prepareCall(sql); // Stored Procedure
        } else {
            pstmt = conn.prepareStatement(sql); // SQL thường
        }
        
        // Đổ dữ liệu vào dấu ?
        for (int i = 0; i < args.length; i++) {
            pstmt.setObject(i + 1, args[i]);
        }
        return pstmt;
    }

    // Hàm thực hiện INSERT, UPDATE, DELETE
    public static int executeUpdate(String sql, Object... args) {
        try {
            PreparedStatement stmt = createPreparedStatement(sql, args);
            if (stmt != null) {
                try {
                    return stmt.executeUpdate();
                } finally {
                    // Đóng kết nối ngay sau khi xong
                    stmt.getConnection().close();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    // Hàm thực hiện SELECT (Trả về ResultSet)
    public static ResultSet executeQuery(String sql, Object... args) {
        try {
            PreparedStatement stmt = createPreparedStatement(sql, args);
            if (stmt != null) {
                return stmt.executeQuery();
                // LƯU Ý: Không đóng connection ở đây, vì nếu đóng thì ResultSet sẽ chết theo.
                // Bên DAO sau khi dùng xong ResultSet phải tự đóng connection.
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}