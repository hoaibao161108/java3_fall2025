package poly.com.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import poly.com.entity.News;
import poly.com.util.JdbcHelper;

public class NewsDAO {

    // Hàm hỗ trợ mapping dữ liệu từ SQL sang Java Object
    private News readFromResultSet(ResultSet rs) throws SQLException {
        News model = new News();
        model.setId(rs.getString("Id"));
        model.setTitle(rs.getString("Title"));
        model.setContent(rs.getString("Content"));
        model.setImage(rs.getString("Image"));
        model.setPostedDate(rs.getDate("PostedDate"));
        model.setAuthor(rs.getString("Author"));
        model.setViewCount(rs.getInt("ViewCount"));
        model.setCategoryId(rs.getString("CategoryId"));
        model.setHome(rs.getBoolean("Home"));
        return model;
    }

    // 1. Lấy TẤT CẢ bài viết (Dành cho ADMIN) 
    public List<News> findAll() {
        String sql = "SELECT * FROM NEWS";
        return select(sql);
    }

    // 2. Lấy bài viết theo Tác giả (Dành cho PHÓNG VIÊN) 
    // Logic: Chỉ hiện tin của riêng mình (WHERE Author = ?)
    public List<News> findByAuthor(String authorId) {
        String sql = "SELECT * FROM NEWS WHERE Author = ?";
        return select(sql, authorId);
    }

    // Hàm chung để chạy câu lệnh Select
    private List<News> select(String sql, Object... args) {
        List<News> list = new ArrayList<>();
        try {
            ResultSet rs = JdbcHelper.executeQuery(sql, args);
            while (rs.next()) {
                list.add(readFromResultSet(rs));
            }
            rs.getStatement().getConnection().close(); // Đóng kết nối
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
}