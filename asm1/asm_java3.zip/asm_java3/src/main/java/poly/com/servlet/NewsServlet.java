package poly.com.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

import poly.com.dao.NewsDAO;
import poly.com.entity.News;
import poly.com.entity.User;

@WebServlet("/NewsServlet")
public class NewsServlet extends HttpServlet {
    
    private NewsDAO newsDAO = new NewsDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 1. Kiểm tra đăng nhập
        HttpSession session = req.getSession();
        User user = (User) session.getAttribute("user");

        if (user == null) {
            resp.sendRedirect("login.jsp"); // Chưa đăng nhập thì đuổi về
            return;
        }

        // 2. Lấy danh sách tin tùy theo vai trò (ĐÚNG YÊU CẦU ĐỀ BÀI)
        List<News> list;
        String targetPage = "";

     // Sửa isRole() thành getRole() nếu entity của bạn dùng Boolean
        if (Boolean.TRUE.equals(user.getRole())) {
            // Là ADMIN: Lấy tất cả bài viết
            list = newsDAO.findAll();
            targetPage = "/views/admin/news-manage.jsp";
        } else {
            // Là PHÓNG VIÊN: Chỉ lấy bài viết của chính mình
            list = newsDAO.findByAuthor(user.getId());
            targetPage = "/views/reporter/news-manage.jsp";
        }

        // 3. Gửi dữ liệu sang JSP và hiển thị
        req.setAttribute("newsList", list);
        req.getRequestDispatcher(targetPage).forward(req, resp);
    }
}
