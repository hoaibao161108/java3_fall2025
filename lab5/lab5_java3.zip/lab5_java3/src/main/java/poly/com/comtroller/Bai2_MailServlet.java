package poly.com.comtroller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import poly.com.utils.Mailer;

import java.io.IOException;

@WebServlet("/mail")
public class Bai2_MailServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Chuyển hướng đến trang form gửi mail
        // Lưu ý: file mail.jsp phải nằm trong thư mục views
        req.getRequestDispatcher("/views/mail.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 1. Nhận tham số từ form
        String to = req.getParameter("to");
        String subject = req.getParameter("subject");
        String body = req.getParameter("body");

        try {
            // 2. Gọi hàm gửi mail từ lớp tiện ích
            Mailer.send(to, subject, body);
            
            // 3. Thông báo thành công
            req.setAttribute("message", "Gửi email thành công đến: " + to);
            
        } catch (Exception e) {
            // 4. Thông báo lỗi nếu gửi thất bại
            e.printStackTrace();
            req.setAttribute("message", "Gửi thất bại! Lỗi: " + e.getMessage());
        }

        // Quay lại trang form để hiển thị thông báo
        req.getRequestDispatcher("/views/mail.jsp").forward(req, resp);
    }
}
