package poly.com.comtroller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.Base64;

@WebServlet("/login")
public class Bai3_LoginServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // --- LOGIC F5 HOẶC MỞ LẠI TRANG: ĐỌC COOKIE ---
        
        String u = "";
        String p = "";
        String checked = "";

        Cookie[] cookies = req.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("user")) {
                    String value = cookie.getValue();
                    try {
                        // Giải mã
                        byte[] decodedBytes = Base64.getDecoder().decode(value);
                        String decodedString = new String(decodedBytes);
                        
                        String[] parts = decodedString.split(":");
                        if (parts.length == 2) {
                            u = parts[0];
                            p = parts[1];
                            checked = "checked"; // Tự động tick checkbox
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        
        // Đẩy dữ liệu đọc được từ Cookie ra form
        req.setAttribute("username", u);
        req.setAttribute("password", p);
        req.setAttribute("checked", checked);
        
        req.getRequestDispatcher("/views/login.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // --- LOGIC KHI BẤM NÚT LOGIN ---
        
        String u = req.getParameter("username");
        String p = req.getParameter("password");
        String remember = req.getParameter("remember");

        // Giả lập check user/pass
        if ("admin".equals(u) && "123".equals(p)) {
            
            // Đăng nhập đúng
            req.setAttribute("message", "Đăng nhập thành công!");
            
            // Xử lý Cookie
            if (remember != null) {
                String info = u + ":" + p;
                String encodedInfo = Base64.getEncoder().encodeToString(info.getBytes());
                
                Cookie cookie = new Cookie("user", encodedInfo);
                cookie.setMaxAge(30 * 24 * 60 * 60); // 30 ngày
                cookie.setPath("/"); 
                resp.addCookie(cookie);
                
                req.setAttribute("checked", "checked"); // Giữ dấu tích
            } else {
                // Nếu bỏ tích thì xóa cookie cũ
                Cookie cookie = new Cookie("user", "");
                cookie.setMaxAge(0);
                cookie.setPath("/");
                resp.addCookie(cookie);
                req.setAttribute("checked", "");
            }
            
        } else {
            // Đăng nhập sai
            req.setAttribute("message", "Sai thông tin đăng nhập!");
            // Nếu người dùng đang tích remember mà nhập sai thì vẫn giữ dấu tích
            req.setAttribute("checked", remember != null ? "checked" : "");
        }

        // QUAN TRỌNG: Luôn gửi lại username và password về form để giữ nguyên dữ liệu
        req.setAttribute("username", u);
        req.setAttribute("password", p);
        
        req.getRequestDispatcher("/views/login.jsp").forward(req, resp);
    }
}