package poly.com.utils;

import java.util.Properties;
import jakarta.mail.Authenticator;
import jakarta.mail.Message;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;

public class Mailer {
    // Thay bằng email của bạn
    private static final String FROM_EMAIL = "zodiacroyalerestaurant@gmail.com"; 
    // Thay bằng Mật khẩu ứng dụng (App Password) 16 ký tự
    private static final String APP_PASSWORD = "ghph gezk xuxk lskd"; 

    public static void send(String to, String subject, String body) {
        try {
            // 1. Cấu hình thông số kết nối Gmail SMTP
            Properties props = new Properties();
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.starttls.enable", "true");
            props.put("mail.smtp.host", "smtp.gmail.com");
            props.put("mail.smtp.port", "587");
            props.put("mail.smtp.ssl.protocols", "TLSv1.2");

            // 2. Tạo phiên làm việc (Session) & Đăng nhập
            Session session = Session.getInstance(props, new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(FROM_EMAIL, APP_PASSWORD);
                }
            });

            // 3. Tạo nội dung email
            MimeMessage mail = new MimeMessage(session);
            mail.setFrom(new InternetAddress(FROM_EMAIL));
            mail.setRecipients(Message.RecipientType.TO, to);
            mail.setSubject(subject, "utf-8");
            mail.setText(body, "utf-8", "html"); // Gửi định dạng HTML

            // 4. Gửi mail
            Transport.send(mail);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}